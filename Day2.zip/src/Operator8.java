public class Operator8 {
    public static void main(String[] args) {
        int var1 = 15;
        char result = (var1 == 10) ? 'O' : 'X';
        System.out.println("결과 : " + result);
    }
}
