public class Variable3 {
    public static void main(String[] args) {
        char var1 = 'A';
        char var2 = '가';
        // char var3 = 'AB';   // 두개 이상의 문자는 char 저장되지 않음
        System.out.println(var1);
        System.out.println(var2);

        char var3 = 100;
        System.out.println(var3);
    }
}
