public class Variable4 {
    public static void main(String[] args) {
        boolean var1 = true;
        boolean var2 = false;
        System.out.println(var1);
        System.out.println(var2);

        System.out.println(5 > 2);  // true
        System.out.println(5 < 2);  // false

        boolean var3 = 5 > 2;
        System.out.println(var3);
    }
}
