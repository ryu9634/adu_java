public class Operator7 {
    public static void main(String[] args) {
        int var1 = 28, var2 = 25, var3 = 2;

        System.out.println("var1 & var2 : " + (var1 & var2));
        System.out.println("var1 | var2 : " + (var1 | var2));
        System.out.println("var1 << var3 : " + (var1 << var3));
        System.out.println("var1 >> var3 : " + (var1 >> var3));
    }
}