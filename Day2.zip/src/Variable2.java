public class Variable2 {
    public static void main(String[] args) {
        float var1 = 123.456F;
        double var2 = 123.456;
        System.out.println(var1);
        System.out.println(var2);
    }
}
