public class While1 {
    public static void main(String[] args) {
        int i = 1;

        // 무한루프
//        while(i <= 5){
//            System.out.println("안녕하세요. Java!");
//        }

        while(i <= 5){
            System.out.println("안녕하세요. Java!");
            i++;
        }
    }
}
