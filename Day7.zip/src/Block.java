public class Block {
    static {
        System.out.println("static 블록을 테스트합니다.");
        System.out.println("이 블록은 객체를 생성할 때 단 한번만 실행됩니다");
    }
    public void print(){
        System.out.println("😒😒😒😒😒😒😒😒😒😒😒");
    }
}
