public class Static1 {
    public static void main(String[] args) {
        Button customer1 = new Button();
        customer1.click();
        customer1.click();
        customer1.click();

        Button customer2 = new Button();
        customer2.click();
    }
}
