public class Static2 {
    public static void main(String[] args) {
        Block block1 = new Block();
        Block block2 = new Block();
        Block block3 = new Block();

        block1.print();
        block2.print();
    }
}
