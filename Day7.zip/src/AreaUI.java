public class AreaUI {
    public static double calcCircle(double radius){
        return (radius * radius) * Math.PI;
    }
}
