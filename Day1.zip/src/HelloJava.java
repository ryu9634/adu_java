/*
    날짜 : 2021년 11월 04일
    작성자 : 류정원
    내용 : Hello Java를 출력함
 */
public class HelloJava {
    public static void main(String[] args) {
        System.out.print("Hello Java\n"); // Hello Java를 출력하고 개행
        System.out.print("Hello 여러분");
    }
}
