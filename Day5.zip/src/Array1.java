public class Array1 {
    public static void main(String[] args) {
//        int[] arr;
//        arr = new int[3];
        int[] arr = new int[3];

        arr[0] = 10;
        arr[1] = 20;
        arr[2] = 30;
//        arr[3] = 40;

        System.out.println(arr[0]);
        System.out.println(arr[1]);
        System.out.println(arr[2]);
    }
}
