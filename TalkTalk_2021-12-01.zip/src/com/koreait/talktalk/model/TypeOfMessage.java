package com.koreait.talktalk.model;

public enum TypeOfMessage {
    DUPLICATE, WELCOME, MESSAGE, WHISPER, EXIT, IMAGE
}
