drop table tb_student;

create table tb_student(
	st_idx bigint auto_increment, 
	st_num  varchar(50) not null,
	st_name varchar(100) not null,
	st_hp varchar(30) not null,
    primary key (st_idx ,st_num),
    st_regdate datetime default now()
);

select*from tb_student;
