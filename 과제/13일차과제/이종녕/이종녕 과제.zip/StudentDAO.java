import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class StudentDAO {
    Connection conn;
    Scanner sc;
    StringBuilder sql;
    PreparedStatement ps;
    ResultSet rs;

    public void insert() throws SQLException {
        sc = new Scanner(System.in);
        System.out.print("학번을 입력해주세요 >>");
        String num = sc.next();
        System.out.print("이름을 입력해주세요 >>");
        String name = sc.next();
        System.out.print("전화번호를 입력해주세요 >>");
        String hp = sc.next();

        try {
            conn = DB.getConnection();
            sql = new StringBuilder();
            sql.append("insert into tb_student (st_num , st_name  , st_hp)");
            sql.append("values(?,?,?)");
            ps = conn.prepareStatement(sql.toString());
            ps.setString(1, num);
            ps.setString(2, name);
            ps.setString(3, hp);
            int result = ps.executeUpdate();
            if (result >= 1) System.out.println("학생 정보를 입력했습니다.");
            else System.out.println("학생 정보를 입력 받지 못했습니다.");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DB.dbclose();
            ps.close();
            ps = null;

        }
    }

    public void list() throws SQLException {
        try {
            conn = DB.getConnection();
            sql = new StringBuilder();
            sql.append("select st_num , st_name , st_hp ,st_hp ,st_regdate from tb_student order by st_num desc");
            ps = conn.prepareStatement(sql.toString());
            rs = ps.executeQuery();
            while (rs.next()) {
                String num = rs.getString("st_num");
                String name = rs.getString("st_name");
                String hp = rs.getString("st_hp");
                String regdate = rs.getString("st_regdate");
                System.out.println("학번 : " + num + ", 이름 : " + name + ", 전화번호 : " + hp + ", 등록일 : " + regdate);

            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DB.dbclose();
            ps.close();
            ps = null;
            rs.close();
            rs = null;

        }
    }

    public void edit() throws SQLException {
        sc = new Scanner(System.in);
        System.out.print("수정할 학번을 입력하세요 > ");
        String num = sc.next();
        System.out.print("수정할 이름을 압력하세요 > ");
        String name = sc.next();
        System.out.print("수정할 전화번호를 입력하세요 > ");
        String hp = sc.next();

        try {
            conn = DB.getConnection();
            sql = new StringBuilder();
            sql.append("update tb_student set st_name = ? , st_hp= ? where st_num = ?");
            ps = conn.prepareStatement(sql.toString());
            ps.setString(1, name);
            ps.setString(2, hp);
            ps.setString(3, num);
            int result = ps.executeUpdate();
            if (result >= 1) System.out.println("학생부 수정 완료");
            else System.out.println("학생부 수정 실패!");


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DB.dbclose();
            ps.close();
            ps = null;
        }


    }

    public void delete() throws SQLException {
        sc = new Scanner(System.in);
        System.out.print("삭제하실 학번을 입력해주세요 > ");
        String word = sc.next();


        try {
            conn = DB.getConnection();
            sql = new StringBuilder();
            sql.append("delete from tb_student where st_num = ?");
            ps = conn.prepareStatement(sql.toString());
            ps.setString(1, word);
            int result = ps.executeUpdate();
            if (result >= 1) System.out.println("단어 삭제 성공");
            else System.out.println("단어 삭제 실패");


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DB.dbclose();
            ps.close();
            ps = null;
        }


    }
}



