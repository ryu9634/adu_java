public class Box {
    private Object obj; // String, Integer, Apple

    public Object getObj() {
        return obj;
    }

    public void setObj(Object obj) {    // String, Integer, Apple
        this.obj = obj;
    }
}
