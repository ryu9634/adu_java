public interface Calc {
    public int min(int x, int y);
}
