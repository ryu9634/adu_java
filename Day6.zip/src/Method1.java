public class Method1 {

    public static void method1(){
        System.out.println("Hello Java!");
    }

    public static void main(String[] args) {
        method1();
        method1();
        method1();
        method1();
    }
}
