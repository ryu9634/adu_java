package com.koreait.talktalk.client;

import com.koreait.talktalk.client.frame.AppFrame;

public class ClientLauncher {
    public static void main(String[] args) {
        AppFrame frame = new AppFrame();
        frame.setVisible(true);
    }
}
